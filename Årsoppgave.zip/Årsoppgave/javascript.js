var olepole = ("ole var på do, ikke gi han fravær");
h1El = document.getElementById();

console.log(h1El);

function knapp(){
    console.log(olepole);
    h1El.innerHTML = olepole;
}




